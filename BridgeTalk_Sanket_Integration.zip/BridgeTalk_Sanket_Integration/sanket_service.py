from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Optional

import cv2
import torch


class SanketService:
    """BridgeTalk wrapper for the pretrained Sanket ISL model."""

    def __init__(self, model_path: Optional[str] = None):
        self.project_root = Path(__file__).resolve().parents[1]
        self.sanket_root = self.project_root / "sanket_source" / "Sanket - ISL Translator"
        self.model_path = Path(model_path) if model_path else self.project_root / "models" / "sanket" / "model_best.pth"
        self.device = torch.device("cpu")
        self.model = None
        self.tokenizer = None
        self.loaded = False

    def load(self) -> None:
        if self.loaded:
            return
        if not self.model_path.exists():
            raise FileNotFoundError(f"Sanket model not found:\n{self.model_path}")
        if not self.sanket_root.exists():
            raise FileNotFoundError(f"Sanket source not found:\n{self.sanket_root}")
        sanket_path = str(self.sanket_root)
        if sanket_path not in sys.path:
            sys.path.insert(0, sanket_path)
        from architecture import DualStreamGMTFormer
        from transformers import AutoTokenizer
        t5_path = self.sanket_root / "cache" / "t5-base"
        if not t5_path.exists():
            raise FileNotFoundError(f"T5 cache not found:\n{t5_path}")
        print("[Sanket] Loading tokenizer...")
        self.tokenizer = AutoTokenizer.from_pretrained(str(t5_path))
        print("[Sanket] Creating architecture...")
        self.model = DualStreamGMTFormer()
        print("[Sanket] Loading checkpoint...")
        checkpoint = torch.load(str(self.model_path), map_location=self.device)
        state_dict = checkpoint.get("model_state_dict", checkpoint) if isinstance(checkpoint, dict) else checkpoint
        missing, unexpected = self.model.load_state_dict(state_dict, strict=False)
        if missing:
            print(f"[Sanket] Missing keys: {len(missing)}")
        if unexpected:
            print(f"[Sanket] Unexpected keys: {len(unexpected)}")
        self.model.to(self.device)
        self.model.eval()
        self.loaded = True
        print("[Sanket] READY")

    def predict_video(self, video_path: str) -> str:
        self.load()
        if not os.path.exists(video_path):
            raise FileNotFoundError(video_path)
        sanket_path = str(self.sanket_root)
        if sanket_path not in sys.path:
            sys.path.insert(0, sanket_path)
        import extract_features
        extract_features.cv2 = cv2
        print("[Sanket] Extracting features...")
        chunks = extract_features.process_continuous_video(video_path, frames_per_chunk=8)
        if not chunks:
            return ""
        predictions = []
        with torch.no_grad():
            for index, (video_tensor, pose_tensor) in enumerate(chunks):
                print(f"[Sanket] Processing {index + 1}/{len(chunks)}")
                try:
                    result = self.model.generate_translation(
                        video_frames=video_tensor.to(self.device, dtype=torch.float32),
                        pose_data=pose_tensor.to(self.device, dtype=torch.float32),
                        tokenizer=self.tokenizer,
                        max_length=15,
                    )
                    if result:
                        predictions.append(str(result).strip())
                except Exception as exc:
                    print("[Sanket] Prediction error:", repr(exc))
        cleaned = []
        for prediction in predictions:
            if not cleaned or prediction.lower() != cleaned[-1].lower():
                cleaned.append(prediction)
        return " ".join(cleaned).strip()

    def test_model(self) -> bool:
        try:
            self.load()
            return self.loaded
        except Exception as exc:
            print("[Sanket] Test failed:", repr(exc))
            return False

    def close(self) -> None:
        self.model = None
        self.tokenizer = None
        self.loaded = False
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
