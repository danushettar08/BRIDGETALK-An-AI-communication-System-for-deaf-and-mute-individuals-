from __future__ import annotations

import os
import tempfile

import cv2
from PySide6.QtCore import QThread, Signal
from services.sanket_service import SanketService


class SanketWorker(QThread):
    """Run Sanket inference without blocking the BridgeTalk UI."""

    result_ready = Signal(str, float)
    error = Signal(str)
    started_processing = Signal()
    finished_processing = Signal()

    def __init__(self, frames, fps: float = 20.0, parent=None):
        super().__init__(parent)
        self.frames = [frame.copy() for frame in frames if frame is not None]
        self.fps = fps

    def run(self):
        self.started_processing.emit()
        video_path = None
        service = None
        try:
            if len(self.frames) < 5:
                raise ValueError("Not enough frames for Sanket recognition.")
            height, width = self.frames[0].shape[:2]
            fd, video_path = tempfile.mkstemp(suffix=".mp4", prefix="bridgetalk_sanket_")
            os.close(fd)
            writer = cv2.VideoWriter(
                video_path,
                cv2.VideoWriter_fourcc(*"mp4v"),
                self.fps,
                (width, height),
            )
            if not writer.isOpened():
                raise RuntimeError("Could not create temporary video.")
            try:
                for frame in self.frames:
                    writer.write(frame)
            finally:
                writer.release()
            print("[SanketWorker] Video created:", video_path)
            service = SanketService()
            prediction = service.predict_video(video_path).strip()
            self.result_ready.emit(prediction, 1.0 if prediction else 0.0)
        except Exception as exc:
            message = f"Sanket recognition failed:\n{exc}"
            print("[SanketWorker]", repr(exc))
            self.error.emit(message)
        finally:
            if service is not None:
                try:
                    service.close()
                except Exception:
                    pass
            if video_path and os.path.exists(video_path):
                try:
                    os.remove(video_path)
                except Exception:
                    pass
            self.finished_processing.emit()
