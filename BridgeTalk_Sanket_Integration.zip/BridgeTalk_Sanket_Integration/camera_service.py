"""
BridgeTalk Camera Service.

Pipeline:

Camera
    â†“
MediaPipe Tasks Hand Landmarker
    â†“
21 Hand Landmarks
    â†“
Existing Landmark Gesture Classifier
    â†“
Gesture â†’ Text
    â†“
Qt UI

Additional word-level pipeline:

Camera
    â†“
MediaPipe Holistic
    â†“
258 keypoint features
    â†“
45-frame sequence
    â†“
ISL LSTM
    â†“
Hello / How are you / Thank you
    â†“
Qt UI
"""

from __future__ import annotations

import cv2

from PySide6.QtCore import QThread, Signal
from PySide6.QtGui import QImage

from services.hand_tracking_service import (
    HandTrackingService,
)

from services.gesture_recognition_service import (
    GestureRecognitionService,
)

from services.gesture_service import (
    GestureService,
)

from services.isl_lstm_service import (
    ISLLSTMService,
)

try:
    from services.sanket_worker import SanketWorker
except Exception:
    SanketWorker = None


class CameraThread(QThread):
    """Background camera and recognition thread."""

    frame_ready = Signal(QImage)

    hand_count_changed = Signal(int)

    handedness_changed = Signal(str)

    gesture_changed = Signal(str, float)

    gesture_text_changed = Signal(str)

    camera_started = Signal()

    camera_stopped = Signal()

    camera_error = Signal(str)

    tracking_error = Signal(str)

    # Sanket ISL model output
    sanket_prediction_changed = Signal(str, float)
    sanket_status_changed = Signal(str)

    def __init__(
        self,
        camera_index: int = 0,
        parent=None,
    ):
        super().__init__(parent)

        self.camera_index = camera_index

        self._running = False

        self._capture = None

        self._tracker = None

        self._recognizer = None

        self._isl_lstm = None

        self._frame_number = 0

        self._last_frame = None

        self._last_gesture = "None"

        self._last_score = 0.0

        self._last_text = ""

        self._last_lstm_prediction = "None"

        # Sanket recording/inference state
        self._sanket_recording = False
        self._sanket_frames = []
        self._sanket_worker = None
        self._sanket_max_frames = 120
        self._sanket_frame_stride = 2

    # ==========================================================
    # RUN
    # ==========================================================

    def run(self) -> None:
        """Run the camera and recognition pipeline."""

        try:

            # --------------------------------------------------
            # CAMERA
            # --------------------------------------------------

            self._capture = cv2.VideoCapture(
                self.camera_index,
                cv2.CAP_DSHOW,
            )

            if not self._capture.isOpened():

                self._capture.release()

                self._capture = cv2.VideoCapture(
                    self.camera_index
                )

            if not self._capture.isOpened():

                self.camera_error.emit(
                    f"Unable to open camera "
                    f"{self.camera_index}."
                )

                return

            # --------------------------------------------------
            # PERFORMANCE
            # --------------------------------------------------

            self._capture.set(
                cv2.CAP_PROP_FRAME_WIDTH,
                640,
            )

            self._capture.set(
                cv2.CAP_PROP_FRAME_HEIGHT,
                480,
            )

            self._capture.set(
                cv2.CAP_PROP_FPS,
                30,
            )

            self._capture.set(
                cv2.CAP_PROP_BUFFERSIZE,
                1,
            )

            # --------------------------------------------------
            # HAND TRACKER
            # --------------------------------------------------

            try:

                self._tracker = (
                    HandTrackingService(
                        max_hands=2,
                        detection_confidence=0.5,
                        tracking_confidence=0.5,
                    )
                )

            except Exception as exc:

                self.tracking_error.emit(
                    "Hand tracking initialization failed:\n"
                    f"{exc}"
                )

                return

            # --------------------------------------------------
            # LANDMARK GESTURE CLASSIFIER
            # --------------------------------------------------

            try:

                self._recognizer = (
                    GestureRecognitionService(
                        max_hands=2
                    )
                )

            except Exception as exc:

                self.tracking_error.emit(
                    "Gesture recognition initialization failed:\n"
                    f"{exc}"
                )

                self._close_tracker()

                return

            # --------------------------------------------------
            # ISL WORD-LEVEL LSTM
            # --------------------------------------------------

            try:

                self._isl_lstm = (
                    ISLLSTMService()
                )

                self._isl_lstm.reset()

            except Exception as exc:

                self.tracking_error.emit(
                    "ISL LSTM initialization failed:\n"
                    f"{exc}"
                )

                self._close_recognizer()

                self._close_tracker()

                return

            # --------------------------------------------------
            # RESET
            # --------------------------------------------------

            self._frame_number = 0

            self._last_gesture = "None"

            self._last_score = 0.0

            self._last_text = ""

            self._last_lstm_prediction = "None"

            self._running = True

            self.camera_started.emit()

            # ==================================================
            # CAMERA LOOP
            # ==================================================

            while self._running:

                success, frame = (
                    self._capture.read()
                )

                if not success:
                    continue

                self._frame_number += 1

                # Collect raw BGR frames for Sanket when recording is active.
                if (
                    self._sanket_recording
                    and self._frame_number % self._sanket_frame_stride == 0
                ):
                    self._sanket_frames.append(frame.copy())

                    if len(self._sanket_frames) >= self._sanket_max_frames:
                        self._sanket_recording = False
                        self._launch_sanket_worker()

                try:

                    # ==================================================
                    # EXISTING HAND TRACKING
                    # ==================================================

                    hand_result = (
                        self._tracker.process(
                            frame
                        )
                    )

                    processed_frame = (
                        hand_result.frame.copy()
                    )

                    # ==================================================
                    # HAND COUNT
                    # ==================================================

                    hand_count = (
                        hand_result.hand_count
                    )

                    self.hand_count_changed.emit(
                        hand_count
                    )

                    # ==================================================
                    # HANDEDNESS
                    # ==================================================

                    if hand_result.handedness:

                        self.handedness_changed.emit(
                            " + ".join(
                                hand_result.handedness
                            )
                        )

                    else:

                        self.handedness_changed.emit(
                            "No hand detected"
                        )

                    # ==================================================
                    # EXISTING GESTURE RECOGNITION
                    # ==================================================

                    if hand_count == 0:

                        self._clear_gesture()

                    else:

                        self._recognize_hands(
                            hand_result
                        )

                    # ==================================================
                    # ISL WORD-LEVEL LSTM
                    # ==================================================

                    if self._isl_lstm is not None:

                        lstm_result = (
                            self._isl_lstm.process_frame(
                                frame
                            )
                        )

                        if lstm_result is not None:

                            lstm_text, lstm_score = (
                                lstm_result
                            )

                            self._last_gesture = (
                                lstm_text
                            )

                            self._last_score = (
                                lstm_score
                            )

                            self._last_text = (
                                lstm_text
                            )

                            self._last_lstm_prediction = (
                                lstm_text
                            )

                            self.gesture_changed.emit(
                                lstm_text,
                                lstm_score,
                            )

                            self.gesture_text_changed.emit(
                                lstm_text
                            )

                    # ==================================================
                    # SAVE FRAME
                    # ==================================================

                    self._last_frame = (
                        processed_frame
                    )

                except Exception as exc:

                    self.tracking_error.emit(
                        str(exc)
                    )

                # ==================================================
                # DISPLAY
                # ==================================================

                if self._last_frame is not None:

                    display_frame = (
                        self._last_frame
                    )

                else:

                    display_frame = frame

                # ==================================================
                # BGR â†’ RGB
                # ==================================================

                rgb = cv2.cvtColor(
                    display_frame,
                    cv2.COLOR_BGR2RGB,
                )

                rgb = rgb.copy()

                height, width, channels = (
                    rgb.shape
                )

                bytes_per_line = (
                    channels * width
                )

                image = QImage(
                    rgb.data,
                    width,
                    height,
                    bytes_per_line,
                    QImage.Format.Format_RGB888,
                ).copy()

                self.frame_ready.emit(
                    image
                )

        except Exception as exc:

            self.camera_error.emit(
                f"Camera error:\n{exc}"
            )

        finally:

            # ==================================================
            # CLEANUP
            # ==================================================

            self._sanket_recording = False
            self._sanket_frames = []

            self._close_lstm()

            self._close_recognizer()

            self._close_tracker()

            self._release_camera()

            self._running = False

            # IMPORTANT:
            # Replace the old camera frame in the UI
            # with a completely black frame.

            self._emit_black_frame()

            self.camera_stopped.emit()

    # ==========================================================
    # SANKET RECORDING / INFERENCE
    # ==========================================================

    def start_sanket_recording(self) -> bool:
        """Start collecting a short camera sequence for Sanket."""
        if not self._running:
            self.sanket_status_changed.emit("Camera is not running")
            return False

        if SanketWorker is None:
            self.sanket_status_changed.emit("SanketWorker unavailable")
            return False

        if self._sanket_worker is not None and self._sanket_worker.isRunning():
            self.sanket_status_changed.emit("Sanket is still processing")
            return False

        self._sanket_frames = []
        self._sanket_recording = True
        self.sanket_status_changed.emit("Recording sign...")
        return True

    def stop_sanket_recording(self) -> bool:
        """Stop collection and start Sanket inference."""
        if not self._sanket_recording:
            return False

        self._sanket_recording = False

        if len(self._sanket_frames) < 5:
            self.sanket_status_changed.emit("Not enough frames")
            self._sanket_frames = []
            return False

        return self._launch_sanket_worker()

    def _launch_sanket_worker(self) -> bool:
        if SanketWorker is None:
            self.sanket_status_changed.emit("SanketWorker unavailable")
            self._sanket_frames = []
            return False

        if self._sanket_worker is not None and self._sanket_worker.isRunning():
            self.sanket_status_changed.emit("Sanket is still processing")
            return False

        frames = [f.copy() for f in self._sanket_frames]
        self._sanket_frames = []

        if len(frames) < 5:
            self.sanket_status_changed.emit("Not enough frames")
            return False

        self.sanket_status_changed.emit("Sanket is processing...")

        worker = SanketWorker(frames=frames, fps=20.0)
        worker.result_ready.connect(self._sanket_result)
        worker.error.connect(self._sanket_error)
        worker.started_processing.connect(
            lambda: self.sanket_status_changed.emit("Sanket processing...")
        )
        worker.finished_processing.connect(self._sanket_finished)

        self._sanket_worker = worker
        worker.start()
        return True

    def _sanket_result(self, text: str, score: float) -> None:
        text = (text or "").strip()
        if text:
            self._last_lstm_prediction = text
            self._last_text = text
            self.sanket_prediction_changed.emit(text, float(score))
            # Reuse the existing UI signal so no interface rewrite is required.
            self.gesture_text_changed.emit(text)
            self.sanket_status_changed.emit(f"Sanket: {text}")
        else:
            self.sanket_prediction_changed.emit("", 0.0)
            self.sanket_status_changed.emit("Sanket found no sign")

    def _sanket_error(self, message: str) -> None:
        self.sanket_status_changed.emit("Sanket error")
        self.tracking_error.emit(message)

    def _sanket_finished(self) -> None:
        self.sanket_status_changed.emit("Sanket ready")

    # ==========================================================
    # RECOGNIZE HANDS
    # ==========================================================

    def _recognize_hands(
        self,
        hand_result,
    ) -> None:
        """Recognize gestures from current hand landmarks."""

        if self._recognizer is None:

            return

        recognized_results = []

        # --------------------------------------------------
        # Process every currently visible hand
        # --------------------------------------------------

        for hand in hand_result.hands:

            result = (
                self._recognizer.recognize_landmarks(
                    hand.landmarks,
                    hand.handedness,
                )
            )

            if result is not None:

                recognized_results.append(
                    result
                )

        # --------------------------------------------------
        # Nothing recognized
        # --------------------------------------------------

        if not recognized_results:

            return

        # --------------------------------------------------
        # Best current gesture
        # --------------------------------------------------

        best = max(
            recognized_results,
            key=lambda result: result.score,
        )

        gesture = best.gesture

        score = float(
            best.score
        )

        # --------------------------------------------------
        # Update state
        # --------------------------------------------------

        self._last_gesture = gesture

        self._last_score = score

        # --------------------------------------------------
        # Gesture signal
        # --------------------------------------------------

        self.gesture_changed.emit(
            gesture,
            score,
        )

        # --------------------------------------------------
        # Gesture â†’ Text
        # --------------------------------------------------

        converted = (
            GestureService.gesture_to_text(
                gesture,
                score,
            )
        )

        self._last_text = (
            converted.text
        )

        self.gesture_text_changed.emit(
            converted.text
        )

    # ==========================================================
    # CLEAR
    # ==========================================================

    def _clear_gesture(self) -> None:
        """Clear gesture when the hand disappears."""

        self._last_gesture = "None"

        self._last_score = 0.0

        self._last_text = ""

        self.gesture_changed.emit(
            "None",
            0.0,
        )

        self.gesture_text_changed.emit(
            ""
        )

    # ==========================================================
    # BLACK CAMERA FRAME
    # ==========================================================

    def _emit_black_frame(self) -> None:
        """
        Replace the last camera image with a black frame
        when the camera is stopped.
        """

        try:

            black_image = QImage(
                640,
                480,
                QImage.Format.Format_RGB888,
            )

            black_image.fill(0)

            self.frame_ready.emit(
                black_image
            )

            self._last_frame = None

        except Exception as exc:

            print(
                "Could not emit black camera frame:",
                exc,
            )

    # ==========================================================
    # STOP
    # ==========================================================

    def stop(self) -> None:
        """Stop camera."""

        self._running = False

    # ==========================================================
    # LSTM CLEANUP
    # ==========================================================

    def _close_lstm(self) -> None:
        """Close ISL LSTM service."""

        if self._isl_lstm is not None:

            try:

                self._isl_lstm.close()

            except Exception:

                pass

            self._isl_lstm = None

    # ==========================================================
    # TRACKER CLEANUP
    # ==========================================================

    def _close_tracker(self) -> None:

        if self._tracker is not None:

            try:

                self._tracker.close()

            except Exception:

                pass

            self._tracker = None

    # ==========================================================
    # RECOGNIZER CLEANUP
    # ==========================================================

    def _close_recognizer(self) -> None:

        if self._recognizer is not None:

            try:

                self._recognizer.close()

            except Exception:

                pass

            self._recognizer = None

    # ==========================================================
    # CAMERA CLEANUP
    # ==========================================================

    def _release_camera(self) -> None:

        if self._capture is not None:

            try:

                self._capture.release()

            except Exception:

                pass

            self._capture = None


# ==============================================================
# HIGH-LEVEL CAMERA SERVICE
# ==============================================================


class CameraService:
    """High-level camera controller."""

    def __init__(self):

        self.thread = None

    def start(
        self,
        camera_index: int = 0,
    ) -> None:
        """Start camera."""

        if self.is_running():

            self.stop()

        self.thread = CameraThread(
            camera_index=camera_index
        )

        self.thread.start()

    def stop(self) -> None:
        """Stop camera."""

        if self.thread is None:

            return

        if self.thread.isRunning():

            self.thread.stop()

            self.thread.wait(3000)

        self.thread = None

    def is_running(self) -> bool:
        """Check camera status."""

        return (
            self.thread is not None
            and self.thread.isRunning()
        )

    def start_sanket_recording(self) -> bool:
        if self.thread is None:
            return False
        return self.thread.start_sanket_recording()

    def stop_sanket_recording(self) -> bool:
        if self.thread is None:
            return False
        return self.thread.stop_sanket_recording()

    def available_cameras(
        self,
        maximum_cameras: int = 5,
    ) -> list[int]:
        """Find available cameras."""

        cameras = []

        for index in range(
            maximum_cameras
        ):

            capture = cv2.VideoCapture(
                index,
                cv2.CAP_DSHOW,
            )

            if capture.isOpened():

                cameras.append(index)

            capture.release()

        return cameras