"""BridgeTalk SQLite communication history service."""

from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional


BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

DATABASE_PATH = DATA_DIR / "bridgetalk_history.db"


class HistoryService:
    """Stores BridgeTalk communication sentences and translations."""

    def __init__(self, database_path: Optional[str | Path] = None):
        self.database_path = Path(database_path or DATABASE_PATH)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._create_tables()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(str(self.database_path))
        connection.row_factory = sqlite3.Row
        return connection

    def _create_tables(self) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS communication_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sentence TEXT NOT NULL,
                    source TEXT NOT NULL DEFAULT 'Communication',
                    translated_text TEXT NOT NULL DEFAULT '',
                    target_language TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            connection.commit()

    def save(
        self,
        sentence: str,
        source: str = "Communication",
        translated_text: str = "",
        target_language: str = "",
    ) -> Optional[int]:
        sentence = str(sentence or "").strip()
        if not sentence:
            return None

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        with self._connect() as connection:
            cursor = connection.execute(
                """
                INSERT INTO communication_history
                (
                    sentence,
                    source,
                    translated_text,
                    target_language,
                    created_at,
                    updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    sentence,
                    source or "Communication",
                    str(translated_text or "").strip(),
                    str(target_language or "").strip(),
                    now,
                    now,
                ),
            )
            connection.commit()
            return int(cursor.lastrowid)

    def save_or_update(
        self,
        sentence: str,
        source: str = "Communication",
        translated_text: str = "",
        target_language: str = "",
    ) -> Optional[int]:
        """
        Save a sentence if it is new.
        If the same sentence already exists, update its translation/details.
        """
        sentence = str(sentence or "").strip()
        if not sentence:
            return None

        translated_text = str(translated_text or "").strip()
        target_language = str(target_language or "").strip()
        source = source or "Communication"
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT id
                FROM communication_history
                WHERE sentence = ?
                ORDER BY id DESC
                LIMIT 1
                """,
                (sentence,),
            ).fetchone()

            if row:
                history_id = int(row["id"])
                connection.execute(
                    """
                    UPDATE communication_history
                    SET source = ?,
                        translated_text = ?,
                        target_language = ?,
                        updated_at = ?
                    WHERE id = ?
                    """,
                    (
                        source,
                        translated_text,
                        target_language,
                        now,
                        history_id,
                    ),
                )
                connection.commit()
                return history_id

            cursor = connection.execute(
                """
                INSERT INTO communication_history
                (
                    sentence,
                    source,
                    translated_text,
                    target_language,
                    created_at,
                    updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    sentence,
                    source,
                    translated_text,
                    target_language,
                    now,
                    now,
                ),
            )
            connection.commit()
            return int(cursor.lastrowid)

    def get_all(self, limit: int = 100) -> list[dict]:
        limit = max(1, int(limit))

        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT
                    id,
                    sentence,
                    source,
                    translated_text,
                    target_language,
                    created_at,
                    updated_at
                FROM communication_history
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()

            return [dict(row) for row in rows]

    def search(self, text: str, limit: int = 100) -> list[dict]:
        text = str(text or "").strip()

        if not text:
            return self.get_all(limit)

        limit = max(1, int(limit))
        pattern = f"%{text}%"

        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT
                    id,
                    sentence,
                    source,
                    translated_text,
                    target_language,
                    created_at,
                    updated_at
                FROM communication_history
                WHERE sentence LIKE ?
                   OR translated_text LIKE ?
                   OR source LIKE ?
                   OR target_language LIKE ?
                ORDER BY id DESC
                LIMIT ?
                """,
                (
                    pattern,
                    pattern,
                    pattern,
                    pattern,
                    limit,
                ),
            ).fetchall()

            return [dict(row) for row in rows]

    def get(self, history_id: int) -> Optional[dict]:
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT
                    id,
                    sentence,
                    source,
                    translated_text,
                    target_language,
                    created_at,
                    updated_at
                FROM communication_history
                WHERE id = ?
                """,
                (int(history_id),),
            ).fetchone()

            return dict(row) if row else None

    def delete(self, history_id: int) -> bool:
        with self._connect() as connection:
            cursor = connection.execute(
                "DELETE FROM communication_history WHERE id = ?",
                (int(history_id),),
            )
            connection.commit()
            return cursor.rowcount > 0

    def clear_all(self) -> bool:
        with self._connect() as connection:
            connection.execute("DELETE FROM communication_history")
            connection.commit()
            return True

    def count(self) -> int:
        with self._connect() as connection:
            return int(
                connection.execute(
                    "SELECT COUNT(*) FROM communication_history"
                ).fetchone()[0]
            )

    def close(self) -> None:
        return None
