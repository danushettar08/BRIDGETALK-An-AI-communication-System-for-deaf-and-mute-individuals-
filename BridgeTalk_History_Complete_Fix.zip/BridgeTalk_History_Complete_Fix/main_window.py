"""
BridgeTalk Main Application Window.
"""

from __future__ import annotations

from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from config.theme import Theme
from utils.theme_manager import ThemeManager

from ui.components.sidebar import Sidebar
from ui.components.topbar import TopBar
from ui.dashboard.dashboard_page import DashboardPage
from ui.gesture.gesture_page import GesturePage
from ui.settings.settings_page import SettingsPage
from ui.history.history_page import HistoryPage


class PlaceholderPage(QWidget):
    """Temporary page used for upcoming modules."""

    def __init__(
        self,
        title: str,
        description: str = "",
        parent=None,
    ):
        super().__init__(
            parent
        )

        layout = QVBoxLayout(
            self
        )

        layout.setContentsMargins(
            28,
            26,
            28,
            28,
        )

        title_label = QLabel(
            title
        )

        title_label.setStyleSheet(
            """
            QLabel {
                font-size: 26px;
                font-weight: 800;
            }
            """
        )

        layout.addWidget(
            title_label
        )

        if description:

            description_label = QLabel(
                description
            )

            description_label.setWordWrap(
                True
            )

            description_label.setStyleSheet(
                """
                QLabel {
                    color: #94A3B8;
                    font-size: 10pt;
                }
                """
            )

            layout.addWidget(
                description_label
            )

        layout.addStretch()


class MainWindow(QMainWindow):
    """Main BridgeTalk application window."""

    def __init__(
        self,
        parent=None,
    ):
        super().__init__(
            parent
        )

        self.setObjectName(
            "BridgeTalkMainWindow"
        )

        self.setWindowTitle(
            "BridgeTalk - AI Communication System"
        )

        self.resize(
            1440,
            900,
        )

        self.setMinimumSize(
            1100,
            700,
        )

        self._build_ui()

    # ==========================================================
    # BUILD UI
    # ==========================================================

    def _build_ui(self) -> None:

        central_widget = QWidget()

        self.setCentralWidget(
            central_widget
        )

        root_layout = QHBoxLayout(
            central_widget
        )

        root_layout.setContentsMargins(
            0,
            0,
            0,
            0,
        )

        root_layout.setSpacing(
            0
        )

        # ======================================================
        # SIDEBAR
        # ======================================================

        self.sidebar = Sidebar()

        root_layout.addWidget(
            self.sidebar
        )

        # ======================================================
        # MAIN CONTENT
        # ======================================================

        content_container = QWidget()

        content_layout = QVBoxLayout(
            content_container
        )

        content_layout.setContentsMargins(
            0,
            0,
            0,
            0,
        )

        content_layout.setSpacing(
            0
        )

        self.topbar = TopBar()

        content_layout.addWidget(
            self.topbar
        )

        self.stack = QStackedWidget()

        content_layout.addWidget(
            self.stack
        )

        root_layout.addWidget(
            content_container,
            1,
        )

        # ======================================================
        # PAGES
        # ======================================================

        self._create_pages()

        # ======================================================
        # NAVIGATION
        # ======================================================

        self.sidebar.page_selected.connect(
            self._change_page
        )

        # ======================================================
        # THEME
        # ======================================================

        self.settings_page.theme_changed.connect(
            self._change_theme
        )

    # ==========================================================
    # CREATE PAGES
    # ==========================================================

    def _create_pages(self) -> None:

        # ------------------------------------------------------
        # 0 — Dashboard
        # ------------------------------------------------------

        self.dashboard_page = (
            DashboardPage()
        )

        # ------------------------------------------------------
        # 1 — COMMUNICATION CENTRE
        #
        # Existing GesturePage already contains:
        #
        # Gesture → Text
        # Gesture → Speech
        # Speech → Text
        # Text → Speech
        # Translation
        #
        # We reuse it instead of creating duplicate pages.
        # ------------------------------------------------------

        self.communication_page = (
            GesturePage()
        )

        # Keep compatibility with existing code that may refer
        # to gesture_page.
        self.gesture_page = (
            self.communication_page
        )

        # ------------------------------------------------------
        # 2 — Scenarios
        # ------------------------------------------------------

        self.scenarios_page = (
            PlaceholderPage(
                "Scenario Assistant",
                "Hospital, Emergency, Bank, Travel, "
                "Classroom and Workplace communication.",
            )
        )

        # ------------------------------------------------------
        # 3 — AI Assistant
        # ------------------------------------------------------

        self.ai_page = (
            PlaceholderPage(
                "AI Communication Assistant",
                "Your intelligent communication companion.",
            )
        )

        # ------------------------------------------------------
        # 4 — History
        # ------------------------------------------------------

        self.history_page = HistoryPage()

        # ------------------------------------------------------
        # 5 — Settings
        # ------------------------------------------------------

        self.settings_page = (
            SettingsPage()
        )

        # ------------------------------------------------------
        # 6 — About
        # ------------------------------------------------------

        self.about_page = (
            PlaceholderPage(
                "About BridgeTalk",
                "AI Communication System for Deaf "
                "and Mute Individuals.",
            )
        )

        # ======================================================
        # PAGE ORDER MUST MATCH SIDEBAR ORDER
        # ======================================================

        self.pages = [
            self.dashboard_page,
            self.communication_page,
            self.scenarios_page,
            self.ai_page,
            self.history_page,
            self.settings_page,
            self.about_page,
        ]

        for page in self.pages:

            self.stack.addWidget(
                page
            )

        self.stack.setCurrentIndex(
            0
        )

    # ==========================================================
    # NAVIGATION
    # ==========================================================

    def _change_page(
        self,
        index: int,
    ) -> None:
        """Switch application page."""

        if not (
            0 <= index < self.stack.count()
        ):
            return

        # Communication page is index 1.
        #
        # Stop camera whenever the user leaves
        # Communication.

        if (
            self.stack.currentWidget()
            is self.communication_page
            and index != 1
        ):

            self.communication_page.stop_camera()

        self.stack.setCurrentIndex(
            index
        )

        self.sidebar.set_active_page(
            index
        )

    # ==========================================================
    # THEME
    # ==========================================================

    def _change_theme(
        self,
        theme_name: str,
    ) -> None:
        """Change application theme."""

        application = (
            QApplication.instance()
        )

        if application is None:
            return

        if (
            theme_name
            == Theme.LIGHT.value
        ):

            selected_theme = Theme.LIGHT

        else:

            selected_theme = Theme.DARK

        ThemeManager.set_theme(
            application,
            selected_theme,
        )

    # ==========================================================
    # CLOSE
    # ==========================================================

    def closeEvent(
        self,
        event,
    ) -> None:
        """Clean up resources before closing."""

        self.communication_page.stop_camera()

        event.accept()