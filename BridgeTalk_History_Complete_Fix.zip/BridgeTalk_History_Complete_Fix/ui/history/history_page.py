"""BridgeTalk Conversation History page."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from services.history_service import HistoryService


BG = "#050712"
PANEL = "#080D1C"
PANEL_2 = "#0B1122"
BORDER = "#202B49"
TEXT = "#F5F7FF"
MUTED = "#8D98B5"
PURPLE = "#8B5CF6"
RED = "#EF4444"
GREEN = "#22C55E"


class HistoryPage(QWidget):
    """Full searchable BridgeTalk communication history screen."""

    def __init__(self, parent=None):
        super().__init__(parent)

        self.history = HistoryService()

        self._build_ui()
        self.refresh_history()

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 26, 28, 28)
        root.setSpacing(16)

        title = QLabel("Conversation History")
        title.setStyleSheet(
            f"""
            QLabel {{
                color: {TEXT};
                font-size: 28px;
                font-weight: 800;
            }}
            """
        )
        root.addWidget(title)

        subtitle = QLabel(
            "Review saved communication, translations and speech output."
        )
        subtitle.setStyleSheet(
            f"""
            QLabel {{
                color: {MUTED};
                font-size: 11pt;
            }}
            """
        )
        root.addWidget(subtitle)

        toolbar = QHBoxLayout()
        toolbar.setSpacing(10)

        self.search = QLineEdit()
        self.search.setPlaceholderText(
            "Search conversations, translations or language..."
        )
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.refresh_history)
        self.search.setStyleSheet(self._input_style())
        toolbar.addWidget(self.search, 1)

        refresh_button = QPushButton("↻  REFRESH")
        refresh_button.clicked.connect(self.refresh_history)
        refresh_button.setStyleSheet(self._button_style())
        toolbar.addWidget(refresh_button)

        clear_button = QPushButton("CLEAR ALL")
        clear_button.clicked.connect(self.clear_all)
        clear_button.setStyleSheet(self._danger_style())
        toolbar.addWidget(clear_button)

        root.addLayout(toolbar)

        self.count_label = QLabel("0 conversations")
        self.count_label.setStyleSheet(
            f"color: {MUTED}; font-size: 10pt; font-weight: 600;"
        )
        root.addWidget(self.count_label)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setStyleSheet(
            "QScrollArea { background: transparent; border: none; }"
        )

        self.container = QWidget()

        self.cards_layout = QVBoxLayout(self.container)
        self.cards_layout.setContentsMargins(2, 2, 8, 10)
        self.cards_layout.setSpacing(12)

        self.scroll.setWidget(self.container)
        root.addWidget(self.scroll, 1)

    def _input_style(self) -> str:
        return f"""
        QLineEdit {{
            background: {PANEL_2};
            color: {TEXT};
            border: 1px solid {BORDER};
            border-radius: 10px;
            padding: 12px 14px;
            font-size: 11pt;
        }}

        QLineEdit:focus {{
            border: 1px solid {PURPLE};
        }}

        QLineEdit::placeholder {{
            color: {MUTED};
        }}
        """

    def _button_style(self) -> str:
        return f"""
        QPushButton {{
            background: {PANEL_2};
            color: {TEXT};
            border: 1px solid {BORDER};
            border-radius: 10px;
            padding: 11px 15px;
            font-weight: 700;
        }}

        QPushButton:hover {{
            border: 1px solid {PURPLE};
            background: #111A31;
        }}

        QPushButton:pressed {{
            background: #151E39;
        }}
        """

    def _danger_style(self) -> str:
        return f"""
        QPushButton {{
            background: #35121A;
            color: #FFB4BE;
            border: 1px solid {RED};
            border-radius: 10px;
            padding: 11px 15px;
            font-weight: 700;
        }}

        QPushButton:hover {{
            background: #501722;
        }}
        """

    def _card_style(self) -> str:
        return f"""
        QFrame#HistoryCard {{
            background: {PANEL};
            border: 1px solid {BORDER};
            border-radius: 16px;
        }}

        QFrame#HistoryCard:hover {{
            border: 1px solid {PURPLE};
        }}
        """

    def refresh_history(self, *_args) -> None:
        query = self.search.text().strip()

        if query:
            entries = self.history.search(query)
        else:
            entries = self.history.get_all()

        self.count_label.setText(
            f"{len(entries)} conversation(s)"
        )

        while self.cards_layout.count():
            item = self.cards_layout.takeAt(0)
            widget = item.widget()

            if widget is not None:
                widget.deleteLater()

        if not entries:
            empty = QFrame()
            empty.setObjectName("HistoryCard")
            empty.setStyleSheet(self._card_style())

            empty_layout = QVBoxLayout(empty)
            empty_layout.setContentsMargins(24, 30, 24, 30)

            empty_title = QLabel("No saved conversations")
            empty_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
            empty_title.setStyleSheet(
                f"""
                color: {TEXT};
                font-size: 16pt;
                font-weight: 700;
                """
            )
            empty_layout.addWidget(empty_title)

            empty_text = QLabel(
                "Use the Communication page to create a sentence. "
                "Saved conversations will appear here automatically."
            )
            empty_text.setWordWrap(True)
            empty_text.setAlignment(Qt.AlignmentFlag.AlignCenter)
            empty_text.setStyleSheet(
                f"color: {MUTED}; font-size: 11pt;"
            )
            empty_layout.addWidget(empty_text)

            self.cards_layout.addWidget(empty)

        else:
            for entry in entries:
                self.cards_layout.addWidget(
                    self._make_card(entry)
                )

        self.cards_layout.addStretch()

    def _make_card(self, entry: dict) -> QFrame:
        card = QFrame()
        card.setObjectName("HistoryCard")
        card.setStyleSheet(self._card_style())

        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 15, 18, 15)
        layout.setSpacing(9)

        top = QHBoxLayout()
        top.setSpacing(10)

        source = QLabel(
            f"{entry.get('source', 'Communication')}  •  "
            f"{entry.get('created_at', '')}"
        )
        source.setStyleSheet(
            f"""
            color: {MUTED};
            font-size: 9pt;
            font-weight: 700;
            """
        )
        top.addWidget(source, 1)

        delete_button = QPushButton("DELETE")
        delete_button.setFixedWidth(80)
        delete_button.setStyleSheet(self._danger_style())
        delete_button.clicked.connect(
            lambda _checked=False, history_id=entry["id"]:
            self.delete_item(history_id)
        )
        top.addWidget(delete_button)

        layout.addLayout(top)

        sentence = QLabel(
            entry.get("sentence", "")
        )
        sentence.setWordWrap(True)
        sentence.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        sentence.setStyleSheet(
            f"""
            color: {TEXT};
            font-size: 14pt;
            font-weight: 700;
            """
        )
        layout.addWidget(sentence)

        translated = (
            entry.get("translated_text", "")
            or ""
        ).strip()

        language = (
            entry.get("target_language", "")
            or ""
        ).strip()

        if translated:
            translation = QLabel(
                f"{language or 'Translation'}: {translated}"
            )
            translation.setWordWrap(True)
            translation.setTextInteractionFlags(
                Qt.TextInteractionFlag.TextSelectableByMouse
            )
            translation.setStyleSheet(
                f"""
                color: {MUTED};
                font-size: 11pt;
                """
            )
            layout.addWidget(translation)

        return card

    def delete_item(self, history_id: int) -> None:
        if self.history.delete(history_id):
            self.refresh_history()

    def clear_all(self) -> None:
        if self.history.count() == 0:
            return

        answer = QMessageBox.question(
            self,
            "Clear History",
            "Delete all saved communication history?",
            QMessageBox.StandardButton.Yes
            | QMessageBox.StandardButton.No,
        )

        if answer == QMessageBox.StandardButton.Yes:
            self.history.clear_all()
            self.refresh_history()
